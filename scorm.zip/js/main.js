
$(function() {
    API = getAPI();
    //API.LMSInitialize("");


});
