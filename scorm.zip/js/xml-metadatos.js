module.exports = {
        "title": "",
        "language": "Inglés",
        "description": "afasdf",
        "keyword": "",
        "date": "2015-03-21",
        "autor": "fasfasdfasf",
        "format": "SCORM1.2",
        "resource": "exercise",
        "context": "Educación post-secundaria no superior",
        "cost": "No",
        "copyright": "CC BY-NC-ND 4.0",
        "classification": "UNESCO",
        "code": "Codigo: 1103",
        "description_classification": "Descripcion: Logica - Lógica general",
        "ccabecera": "Logica",
        "cespecificos": "Lógica general",
        "subitems": "--"
}